package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterX : AppCompatActivity() {
    var NextX: Button? = null
    var PrevX: Button? = null
    var FirstX: Button? = null
    var LastX: Button? = null
    var OverviewX: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_x)
        NextX = findViewById(R.id.nextX)
        PrevX = findViewById(R.id.prevX)
        FirstX = findViewById(R.id.firstX)
        LastX = findViewById(R.id.lastX)
        OverviewX = findViewById(R.id.overviewX)

        NextX!!.setOnClickListener(View.OnClickListener {
            val intentX = Intent(this@letterX, letterY::class.java)
            startActivity(intentX)
        })
        PrevX!!.setOnClickListener(View.OnClickListener {
            val intentX = Intent(this@letterX, letterW::class.java)
            startActivity(intentX)
        })
        FirstX!!.setOnClickListener(View.OnClickListener {
            val intentX = Intent(this@letterX, letterA::class.java)
            startActivity(intentX)
        })
        LastX!!.setOnClickListener(View.OnClickListener {
            val intentX = Intent(this@letterX, letterZ::class.java)
            startActivity(intentX)
        })
        OverviewX!!.setOnClickListener(View.OnClickListener {
            val intentX = Intent(this@letterX, MainActivity::class.java)
            startActivity(intentX)
        })
    }
}