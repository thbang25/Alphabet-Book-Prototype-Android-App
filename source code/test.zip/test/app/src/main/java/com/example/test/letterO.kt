package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterO : AppCompatActivity() {
    var NextO: Button? = null
    var PrevO: Button? = null
    var FirstO: Button? = null
    var LastO: Button? = null
    var OverviewO: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_o)
        NextO = findViewById(R.id.nextO)
        PrevO = findViewById(R.id.prevO)
        FirstO = findViewById(R.id.firstO)
        LastO = findViewById(R.id.lastO)
        OverviewO = findViewById(R.id.overviewO)
        NextO!!.setOnClickListener(View.OnClickListener {
            val intentO = Intent(this@letterO, letterP::class.java)
            startActivity(intentO)
        })
        PrevO!!.setOnClickListener(View.OnClickListener {
            val intentO = Intent(this@letterO, letterN::class.java)
            startActivity(intentO)
        })
        FirstO!!.setOnClickListener(View.OnClickListener {
            val intentO = Intent(this@letterO, letterA::class.java)
            startActivity(intentO)
        })
        LastO!!.setOnClickListener(View.OnClickListener {
            val intentO = Intent(this@letterO, letterZ::class.java)
            startActivity(intentO)
        })
        OverviewO!!.setOnClickListener(View.OnClickListener {
            val intentO = Intent(this@letterO, MainActivity::class.java)
            startActivity(intentO)
        })
    }
}