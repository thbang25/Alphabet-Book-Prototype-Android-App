package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterT : AppCompatActivity() {
    var NextT: Button? = null
    var PrevT: Button? = null
    var FirstT: Button? = null
    var LastT: Button? = null
    var OverviewT: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_t)
        NextT = findViewById(R.id.nextT)
        PrevT = findViewById(R.id.prevT)
        FirstT = findViewById(R.id.firstT)
        LastT = findViewById(R.id.lastT)
        OverviewT = findViewById(R.id.overviewT)

        NextT!!.setOnClickListener(View.OnClickListener {
            val intentT = Intent(this@letterT, letterU::class.java)
            startActivity(intentT)
        })
        PrevT!!.setOnClickListener(View.OnClickListener {
            val intentT = Intent(this@letterT, letterS::class.java)
            startActivity(intentT)
        })
        FirstT!!.setOnClickListener(View.OnClickListener {
            val intentT = Intent(this@letterT, letterA::class.java)
            startActivity(intentT)
        })
        LastT!!.setOnClickListener(View.OnClickListener {
            val intentT = Intent(this@letterT, letterZ::class.java)
            startActivity(intentT)
        })
        OverviewT!!.setOnClickListener(View.OnClickListener {
            val intentT = Intent(this@letterT, MainActivity::class.java)
            startActivity(intentT)
        })
    }
}