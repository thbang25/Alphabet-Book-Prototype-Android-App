package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterB : AppCompatActivity() {
    var NextB: Button? = null
    var PrevB: Button? = null
    var FirstB: Button? = null
    var LastB: Button? = null
    var OverviewB: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_b)
        NextB = findViewById(R.id.nextB)
        PrevB = findViewById(R.id.prevB)
        FirstB = findViewById(R.id.firstB)
        LastB = findViewById(R.id.lastB)
        OverviewB = findViewById(R.id.overviewB)

        NextB!!.setOnClickListener(View.OnClickListener {
            val intentThree = Intent(this@letterB, letterC::class.java)
            startActivity(intentThree)
        })
        PrevB!!.setOnClickListener(View.OnClickListener {
            val intentThree = Intent(this@letterB, letterA::class.java)
            startActivity(intentThree)
        })
        FirstB!!.setOnClickListener(View.OnClickListener {
            val intentThree = Intent(this@letterB, letterA::class.java)
            startActivity(intentThree)
        })
        LastB!!.setOnClickListener(View.OnClickListener {
            val intentThree = Intent(this@letterB, letterZ::class.java)
            startActivity(intentThree)
        })
        OverviewB!!.setOnClickListener(View.OnClickListener {
            val intentThree = Intent(this@letterB, MainActivity::class.java)
            startActivity(intentThree)
        })
    }
}