package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterY : AppCompatActivity() {
    var NextY: Button? = null
    var PrevY: Button? = null
    var FirstY: Button? = null
    var LastY: Button? = null
    var OverviewY: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_y)
        NextY = findViewById(R.id.nextY)
        PrevY = findViewById(R.id.prevY)
        FirstY = findViewById(R.id.firstY)
        LastY = findViewById(R.id.lastY)
        OverviewY = findViewById(R.id.overviewY)

        NextY!!.setOnClickListener(View.OnClickListener {
            val intentY = Intent(this@letterY, letterZ::class.java)
            startActivity(intentY)
        })
        PrevY!!.setOnClickListener(View.OnClickListener {
            val intentY = Intent(this@letterY, letterX::class.java)
            startActivity(intentY)
        })
        FirstY!!.setOnClickListener(View.OnClickListener {
            val intentY = Intent(this@letterY, letterA::class.java)
            startActivity(intentY)
        })
        LastY!!.setOnClickListener(View.OnClickListener {
            val intentY = Intent(this@letterY, letterZ::class.java)
            startActivity(intentY)
        })
        OverviewY!!.setOnClickListener(View.OnClickListener {
            val intentY = Intent(this@letterY, MainActivity::class.java)
            startActivity(intentY)
        })
    }
}