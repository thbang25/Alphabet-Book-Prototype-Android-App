package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class letterA : AppCompatActivity() {
    var Next: Button? = null
    var Last: Button? = null
    var OverviewA: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter)

        Next = findViewById(R.id.next)
        Last = findViewById(R.id.last)
        OverviewA = findViewById(R.id.overviewA)

        Next!!.setOnClickListener(View.OnClickListener {
            val intentTwo = Intent(this@letterA, letterB::class.java)
            startActivity(intentTwo)
        })
        Last!!.setOnClickListener(View.OnClickListener {
            val intentTwo = Intent(this@letterA, letterZ::class.java)
            startActivity(intentTwo)
        })
        OverviewA!!.setOnClickListener(View.OnClickListener {
            val intentTwo = Intent(this@letterA, MainActivity::class.java)
            startActivity(intentTwo)
        })
    }
}