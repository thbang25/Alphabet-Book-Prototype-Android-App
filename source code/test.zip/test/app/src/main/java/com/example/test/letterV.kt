package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterV : AppCompatActivity() {
    var NextV: Button? = null
    var PrevV: Button? = null
    var FirstV: Button? = null
    var LastV: Button? = null
    var OverviewV: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_v)
        NextV = findViewById(R.id.nextV)
        PrevV = findViewById(R.id.prevV)
        FirstV = findViewById(R.id.firstV)
        LastV = findViewById(R.id.lastV)
        OverviewV = findViewById(R.id.overviewV)

        NextV!!.setOnClickListener(View.OnClickListener {
            val intentV = Intent(this@letterV, letterW::class.java)
            startActivity(intentV)
        })
        PrevV!!.setOnClickListener(View.OnClickListener {
            val intentV = Intent(this@letterV, letterU::class.java)
            startActivity(intentV)
        })
        FirstV!!.setOnClickListener(View.OnClickListener {
            val intentV = Intent(this@letterV, letterA::class.java)
            startActivity(intentV)
        })
        LastV!!.setOnClickListener(View.OnClickListener {
            val intentV = Intent(this@letterV, letterZ::class.java)
            startActivity(intentV)
        })
        OverviewV!!.setOnClickListener(View.OnClickListener {
            val intentV = Intent(this@letterV, MainActivity::class.java)
            startActivity(intentV)
        })
    }
}