package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterW : AppCompatActivity() {
    var NextW: Button? = null
    var PrevW: Button? = null
    var FirstW: Button? = null
    var LastW: Button? = null
    var OverviewW: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_w)
        NextW = findViewById(R.id.nextW)
        PrevW = findViewById(R.id.prevW)
        FirstW = findViewById(R.id.firstW)
        LastW = findViewById(R.id.lastW)
        OverviewW = findViewById(R.id.overviewW)

        NextW!!.setOnClickListener(View.OnClickListener {
            val intentW = Intent(this@letterW, letterX::class.java)
            startActivity(intentW)
        })
        PrevW!!.setOnClickListener(View.OnClickListener {
            val intentW = Intent(this@letterW, letterV::class.java)
            startActivity(intentW)
        })
        FirstW!!.setOnClickListener(View.OnClickListener {
            val intentW = Intent(this@letterW, letterA::class.java)
            startActivity(intentW)
        })
        LastW!!.setOnClickListener(View.OnClickListener {
            val intentW = Intent(this@letterW, letterZ::class.java)
            startActivity(intentW)
        })
        OverviewW!!.setOnClickListener(View.OnClickListener {
            val intentW = Intent(this@letterW, MainActivity::class.java)
            startActivity(intentW)
        })
    }
}