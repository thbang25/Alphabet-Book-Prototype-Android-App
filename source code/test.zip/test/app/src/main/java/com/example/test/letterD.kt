package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterD : AppCompatActivity() {
    var NextD: Button? = null
    var PrevD: Button? = null
    var FirstD: Button? = null
    var LastD: Button? = null
    var OverviewD: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_d)
        NextD = findViewById(R.id.nextD)
        PrevD = findViewById(R.id.prevD)
        FirstD = findViewById(R.id.firstD)
        LastD = findViewById(R.id.lastD)
        OverviewD = findViewById(R.id.overviewD)

        NextD!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterD, letterE::class.java)
            startActivity(intentFour)
        })
        PrevD!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterD, letterC::class.java)
            startActivity(intentFour)
        })
        FirstD!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterD, letterA::class.java)
            startActivity(intentFour)
        })
        LastD!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterD, letterZ::class.java)
            startActivity(intentFour)
        })
        OverviewD!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterD, MainActivity::class.java)
            startActivity(intentFour)
        })
    }
}