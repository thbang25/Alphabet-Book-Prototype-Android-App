package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View
import android.widget.Button
import android.widget.ViewFlipper
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    private var butt: Button? = null
    private var butt1: Button? = null
    private var butt2: Button? = null
    private var butt3: Button? = null
    private var butt4: Button? = null
    private var butt5: Button? = null
    private var butt6: Button? = null
    private var butt7: Button? = null
    private var butt8: Button? = null
    private var butt9: Button? = null
    private var butt10: Button? = null
    private var butt11: Button? = null
    private var butt12: Button? = null
    private var butt13: Button? = null
    private var butt14: Button? = null
    private var butt15: Button? = null
    private var butt16: Button? = null
    private var butt17: Button? = null
    private var butt18: Button? = null
    private var butt19: Button? = null
    private var butt20: Button? = null
    private var butt21: Button? = null
    private var butt22: Button? = null
    private var butt23: Button? = null
    private var butt24: Button? = null
    private var butt25: Button? = null
    var viewFlipper: ViewFlipper? = null
    var next: Button? = null
    var previous: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        butt = findViewById<View>(R.id.button1) as Button
        butt1 = findViewById<View>(R.id.button2) as Button
        butt2 = findViewById<View>(R.id.button3) as Button
        butt3 = findViewById<View>(R.id.button4) as Button
        butt4 = findViewById<View>(R.id.button5) as Button
        butt5 = findViewById<View>(R.id.button6) as Button
        butt6 = findViewById<View>(R.id.button7) as Button
        butt7 = findViewById<View>(R.id.button8) as Button
        butt8 = findViewById<View>(R.id.button9) as Button
        butt9 = findViewById<View>(R.id.button10) as Button
        butt10 = findViewById<View>(R.id.button11) as Button
        butt11 = findViewById<View>(R.id.button12) as Button
        butt12 = findViewById<View>(R.id.button13) as Button
        butt13 = findViewById<View>(R.id.button14) as Button
        butt14 = findViewById<View>(R.id.button15) as Button
        butt15 = findViewById<View>(R.id.button16) as Button
        butt16 = findViewById<View>(R.id.button17) as Button
        butt17 = findViewById<View>(R.id.button18) as Button
        butt18 = findViewById<View>(R.id.button19) as Button
        butt19 = findViewById<View>(R.id.button20) as Button
        butt20 = findViewById<View>(R.id.button21) as Button
        butt21 = findViewById<View>(R.id.button22) as Button
        butt22 = findViewById<View>(R.id.button23) as Button
        butt23 = findViewById<View>(R.id.button24) as Button
        butt24 = findViewById<View>(R.id.button25) as Button
        butt25 = findViewById<View>(R.id.button26) as Button
        butt!!.setOnClickListener { openletterA() }
        butt1!!.setOnClickListener { openletterB() }
        butt2!!.setOnClickListener { openletterC() }
        butt3!!.setOnClickListener { openletterD() }
        butt4!!.setOnClickListener { openletterE() }
        butt5!!.setOnClickListener { openletterF() }
        butt6!!.setOnClickListener { openletterG() }
        butt7!!.setOnClickListener { openletterH() }
        butt8!!.setOnClickListener { openletterI() }
        butt9!!.setOnClickListener { openletterJ() }
        butt10!!.setOnClickListener { openletterK() }
        butt11!!.setOnClickListener { openletterL() }
        butt12!!.setOnClickListener { openletterM() }
        butt13!!.setOnClickListener { openletterN() }
        butt14!!.setOnClickListener { openletterO() }
        butt15!!.setOnClickListener { openletterP() }
        butt16!!.setOnClickListener { openletterQ() }
        butt17!!.setOnClickListener { openletterR() }
        butt18!!.setOnClickListener { openletterS() }
        butt19!!.setOnClickListener { openletterT() }
        butt20!!.setOnClickListener { openletterU() }
        butt21!!.setOnClickListener { openletterV() }
        butt22!!.setOnClickListener { openletterW() }
        butt23!!.setOnClickListener { openletterX() }
        butt24!!.setOnClickListener { openletterY() }
        butt25!!.setOnClickListener { openletterZ() }
    } //END BUTTONS

    fun openletterA() {
        val intent = Intent(this, letterA::class.java)
        startActivity(intent)
    }

    fun openletterB() {
        val intent = Intent(this, letterB::class.java)
        startActivity(intent)
    }

    fun openletterC() {
        val intent = Intent(this, letterC::class.java)
        startActivity(intent)
    }

    fun openletterD() {
        val intent = Intent(this, letterD::class.java)
        startActivity(intent)
    }

    fun openletterE() {
        val intent = Intent(this, letterE::class.java)
        startActivity(intent)
    }

    fun openletterF() {
        val intent = Intent(this, letterF::class.java)
        startActivity(intent)
    }

    fun openletterG() {
        val intent = Intent(this, letterG::class.java)
        startActivity(intent)
    }

    fun openletterH() {
        val intent = Intent(this, letterH::class.java)
        startActivity(intent)
    }

    fun openletterI() {
        val intent = Intent(this, letterI::class.java)
        startActivity(intent)
    }

    fun openletterJ() {
        val intent = Intent(this, letterJ::class.java)
        startActivity(intent)
    }

    fun openletterK() {
        val intent = Intent(this, letterK::class.java)
        startActivity(intent)
    }

    fun openletterL() {
        val intent = Intent(this, letterL::class.java)
        startActivity(intent)
    }

    fun openletterM() {
        val intent = Intent(this, letterM::class.java)
        startActivity(intent)
    }

    fun openletterN() {
        val intent = Intent(this, letterN::class.java)
        startActivity(intent)
    }

    fun openletterO() {
        val intent = Intent(this, letterO::class.java)
        startActivity(intent)
    }

    fun openletterP() {
        val intent = Intent(this, letterP::class.java)
        startActivity(intent)
    }

    fun openletterQ() {
        val intent = Intent(this, letterQ::class.java)
        startActivity(intent)
    }

    fun openletterR() {
        val intent = Intent(this, letterR::class.java)
        startActivity(intent)
    }

    fun openletterS() {
        val intent = Intent(this, letterS::class.java)
        startActivity(intent)
    }

    fun openletterT() {
        val intent = Intent(this, letterT::class.java)
        startActivity(intent)
    }

    fun openletterU() {
        val intent = Intent(this, letterU::class.java)
        startActivity(intent)
    }

    fun openletterV() {
        val intent = Intent(this, letterV::class.java)
        startActivity(intent)
    }

    fun openletterW() {
        val intent = Intent(this, letterW::class.java)
        startActivity(intent)
    }

    fun openletterX() {
        val intent = Intent(this, letterX::class.java)
        startActivity(intent)
    }

    fun openletterY() {
        val intent = Intent(this, letterY::class.java)
        startActivity(intent)
    }

    fun openletterZ() {
        val intent = Intent(this, letterZ::class.java)
        startActivity(intent)
    }
} //END MAIN ACTIVITY
