package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterN : AppCompatActivity() {
    var NextN: Button? = null
    var PrevN: Button? = null
    var FirstN: Button? = null
    var LastN: Button? = null
    var OverviewN: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_n)
        NextN = findViewById(R.id.nextN)
        PrevN = findViewById(R.id.prevN)
        FirstN = findViewById(R.id.firstN)
        LastN = findViewById(R.id.lastN)
        OverviewN = findViewById(R.id.overviewN)
        NextN!!.setOnClickListener(View.OnClickListener {
            val intentN = Intent(this@letterN, letterO::class.java)
            startActivity(intentN)
        })
        PrevN!!.setOnClickListener(View.OnClickListener {
            val intentN = Intent(this@letterN, letterM::class.java)
            startActivity(intentN)
        })
        FirstN!!.setOnClickListener(View.OnClickListener {
            val intentN = Intent(this@letterN, letterA::class.java)
            startActivity(intentN)
        })
        LastN!!.setOnClickListener(View.OnClickListener {
            val intentN = Intent(this@letterN, letterZ::class.java)
            startActivity(intentN)
        })
        OverviewN!!.setOnClickListener(View.OnClickListener {
            val intentN = Intent(this@letterN, MainActivity::class.java)
            startActivity(intentN)
        })
    }
}