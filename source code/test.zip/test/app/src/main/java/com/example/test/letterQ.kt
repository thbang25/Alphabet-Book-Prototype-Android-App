package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterQ : AppCompatActivity() {
    var NextQ: Button? = null
    var PrevQ: Button? = null
    var FirstQ: Button? = null
    var LastQ: Button? = null
    var OverviewQ: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_q)
        NextQ = findViewById(R.id.nextQ)
        PrevQ = findViewById(R.id.prevQ)
        FirstQ = findViewById(R.id.firstQ)
        LastQ = findViewById(R.id.lastQ)
        OverviewQ = findViewById(R.id.overviewQ)

        NextQ!!.setOnClickListener(View.OnClickListener {
            val intentQ = Intent(this@letterQ, letterR::class.java)
            startActivity(intentQ)
        })
        PrevQ!!.setOnClickListener(View.OnClickListener {
            val intentQ = Intent(this@letterQ, letterP::class.java)
            startActivity(intentQ)
        })
        FirstQ!!.setOnClickListener(View.OnClickListener {
            val intentQ = Intent(this@letterQ, letterA::class.java)
            startActivity(intentQ)
        })
        LastQ!!.setOnClickListener(View.OnClickListener {
            val intentQ = Intent(this@letterQ, letterZ::class.java)
            startActivity(intentQ)
        })
        OverviewQ!!.setOnClickListener(View.OnClickListener {
            val intentQ = Intent(this@letterQ, MainActivity::class.java)
            startActivity(intentQ)
        })
    }
}