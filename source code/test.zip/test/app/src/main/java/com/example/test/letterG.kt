package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterG : AppCompatActivity() {
    var NextG: Button? = null
    var PrevG: Button? = null
    var FirstG: Button? = null
    var LastG: Button? = null
    var OverviewG: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_g)
        NextG = findViewById(R.id.nextG)
        PrevG = findViewById(R.id.prevG)
        FirstG = findViewById(R.id.firstG)
        LastG = findViewById(R.id.lastG)
        OverviewG = findViewById(R.id.overviewG)

        NextG!!.setOnClickListener(View.OnClickListener {
            val intentSeven = Intent(this@letterG, letterH::class.java)
            startActivity(intentSeven)
        })
        PrevG!!.setOnClickListener(View.OnClickListener {
            val intentSeven = Intent(this@letterG, letterF::class.java)
            startActivity(intentSeven)
        })
        FirstG!!.setOnClickListener(View.OnClickListener {
            val intentSeven = Intent(this@letterG, letterA::class.java)
            startActivity(intentSeven)
        })
        LastG!!.setOnClickListener(View.OnClickListener {
            val intentSeven = Intent(this@letterG, letterZ::class.java)
            startActivity(intentSeven)
        })
        OverviewG!!.setOnClickListener(View.OnClickListener {
            val intentSeven = Intent(this@letterG, MainActivity::class.java)
            startActivity(intentSeven)
        })
    }
}