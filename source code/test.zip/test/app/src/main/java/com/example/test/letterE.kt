package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterE : AppCompatActivity() {
    var elephant: Button? = null
    var elephantTwo: Button? = null
    var elephantThree: Button? = null
    var LastE: Button? = null
    var OverviewE: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_e)
        elephant = findViewById(R.id.nextE)
        elephantTwo = findViewById(R.id.prevE)
        elephantThree = findViewById(R.id.firstE)
        LastE = findViewById(R.id.lastE)
        OverviewE = findViewById(R.id.overviewE)

        elephant!!.setOnClickListener(View.OnClickListener {
            val intentFive = Intent(this@letterE, letterF::class.java)
            startActivity(intentFive)
        })
        elephantTwo!!.setOnClickListener(View.OnClickListener {
            val intentFive = Intent(this@letterE, letterD::class.java)
            startActivity(intentFive)
        })
        elephantThree!!.setOnClickListener(View.OnClickListener {
            val intentFive = Intent(this@letterE, letterA::class.java)
            startActivity(intentFive)
        })
        LastE!!.setOnClickListener(View.OnClickListener {
            val intentFive = Intent(this@letterE, letterZ::class.java)
            startActivity(intentFive)
        })
        OverviewE!!.setOnClickListener(View.OnClickListener {
            val intentFive = Intent(this@letterE, MainActivity::class.java)
            startActivity(intentFive)
        })
    }
}