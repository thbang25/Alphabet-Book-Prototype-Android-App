package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterH : AppCompatActivity() {
    var NextH: Button? = null
    var PrevH: Button? = null
    var FirstH: Button? = null
    var LastH: Button? = null
    var OverviewH: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_h)
        NextH = findViewById(R.id.nextH)
        PrevH = findViewById(R.id.prevH)
        FirstH = findViewById(R.id.firstH)
        LastH = findViewById(R.id.lastH)
        OverviewH = findViewById(R.id.overviewH)

        NextH!!.setOnClickListener(View.OnClickListener {
            val intentH = Intent(this@letterH, letterI::class.java)
            startActivity(intentH)
        })
        PrevH!!.setOnClickListener(View.OnClickListener {
            val intentH = Intent(this@letterH, letterG::class.java)
            startActivity(intentH)
        })
        FirstH!!.setOnClickListener(View.OnClickListener {
            val intentH = Intent(this@letterH, letterA::class.java)
            startActivity(intentH)
        })
        LastH!!.setOnClickListener(View.OnClickListener {
            val intentH = Intent(this@letterH, letterZ::class.java)
            startActivity(intentH)
        })
        OverviewH!!.setOnClickListener(View.OnClickListener {
            val intentH = Intent(this@letterH, MainActivity::class.java)
            startActivity(intentH)
        })
    }
}