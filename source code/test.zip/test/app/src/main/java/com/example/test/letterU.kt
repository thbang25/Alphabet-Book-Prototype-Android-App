package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterU : AppCompatActivity() {
    var NextU: Button? = null
    var PrevU: Button? = null
    var FirstU: Button? = null
    var LastU: Button? = null
    var OverviewU: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_u)
        NextU = findViewById(R.id.nextU)
        PrevU = findViewById(R.id.prevU)
        FirstU = findViewById(R.id.firstU)
        LastU = findViewById(R.id.lastU)
        OverviewU = findViewById(R.id.overviewU)

        NextU!!.setOnClickListener(View.OnClickListener {
            val intentU = Intent(this@letterU, letterV::class.java)
            startActivity(intentU)
        })
        PrevU!!.setOnClickListener(View.OnClickListener {
            val intentU = Intent(this@letterU, letterT::class.java)
            startActivity(intentU)
        })
        FirstU!!.setOnClickListener(View.OnClickListener {
            val intentU = Intent(this@letterU, letterA::class.java)
            startActivity(intentU)
        })
        LastU!!.setOnClickListener(View.OnClickListener {
            val intentU = Intent(this@letterU, letterZ::class.java)
            startActivity(intentU)
        })
        OverviewU!!.setOnClickListener(View.OnClickListener {
            val intentU = Intent(this@letterU, MainActivity::class.java)
            startActivity(intentU)
        })
    }
}