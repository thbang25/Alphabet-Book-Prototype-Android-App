package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterF : AppCompatActivity() {
    var NextF: Button? = null
    var PrevF: Button? = null
    var FirstF: Button? = null
    var LastF: Button? = null
    var OverviewF: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_f)
        NextF = findViewById(R.id.nextF)
        PrevF = findViewById(R.id.prevF)
        FirstF = findViewById(R.id.firstF)
        LastF = findViewById(R.id.lastF)
        OverviewF = findViewById(R.id.overviewF)

        NextF!!.setOnClickListener(View.OnClickListener {
            val intentSix = Intent(this@letterF, letterG::class.java)
            startActivity(intentSix)
        })
        PrevF!!.setOnClickListener(View.OnClickListener {
            val intentSix = Intent(this@letterF, letterE::class.java)
            startActivity(intentSix)
        })
        FirstF!!.setOnClickListener(View.OnClickListener {
            val intentSix = Intent(this@letterF, letterA::class.java)
            startActivity(intentSix)
        })
        LastF!!.setOnClickListener(View.OnClickListener {
            val intentSix = Intent(this@letterF, letterZ::class.java)
            startActivity(intentSix)
        })
        OverviewF!!.setOnClickListener(View.OnClickListener {
            val intentSix = Intent(this@letterF, MainActivity::class.java)
            startActivity(intentSix)
        })
    }
}