package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterL : AppCompatActivity() {
    var NextL: Button? = null
    var PrevL: Button? = null
    var FirstL: Button? = null
    var LastL: Button? = null
    var OverviewL: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_l)
        NextL = findViewById(R.id.nextL)
        PrevL = findViewById(R.id.prevL)
        FirstL = findViewById(R.id.firstL)
        LastL = findViewById(R.id.lastL)
        OverviewL = findViewById(R.id.overviewL)
        NextL!!.setOnClickListener(View.OnClickListener {
            val intentL = Intent(this@letterL, letterM::class.java)
            startActivity(intentL)
        })
        PrevL!!.setOnClickListener(View.OnClickListener {
            val intentL = Intent(this@letterL, letterK::class.java)
            startActivity(intentL)
        })
        FirstL!!.setOnClickListener(View.OnClickListener {
            val intentL = Intent(this@letterL, letterA::class.java)
            startActivity(intentL)
        })
        LastL!!.setOnClickListener(View.OnClickListener {
            val intentL = Intent(this@letterL, letterZ::class.java)
            startActivity(intentL)
        })
        OverviewL!!.setOnClickListener(View.OnClickListener {
            val intentL = Intent(this@letterL, MainActivity::class.java)
            startActivity(intentL)
        })
    }
}