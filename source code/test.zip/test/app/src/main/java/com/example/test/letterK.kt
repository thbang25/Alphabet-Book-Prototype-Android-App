package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterK : AppCompatActivity() {
    var NextK: Button? = null
    var PrevK: Button? = null
    var FirstK: Button? = null
    var LastK: Button? = null
    var OverviewK: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_k)
        NextK = findViewById(R.id.nextK)
        PrevK = findViewById(R.id.prevK)
        FirstK = findViewById(R.id.firstK)
        LastK = findViewById(R.id.lastK)
        OverviewK = findViewById(R.id.overviewK)
        NextK!!.setOnClickListener(View.OnClickListener {
            val intentK = Intent(this@letterK, letterL::class.java)
            startActivity(intentK)
        })
        PrevK!!.setOnClickListener(View.OnClickListener {
            val intentK = Intent(this@letterK, letterJ::class.java)
            startActivity(intentK)
        })
        FirstK!!.setOnClickListener(View.OnClickListener {
            val intentK = Intent(this@letterK, letterA::class.java)
            startActivity(intentK)
        })
        LastK!!.setOnClickListener(View.OnClickListener {
            val intentK = Intent(this@letterK, letterZ::class.java)
            startActivity(intentK)
        })
        OverviewK!!.setOnClickListener(View.OnClickListener {
            val intentK = Intent(this@letterK, MainActivity::class.java)
            startActivity(intentK)
        })
    }
}