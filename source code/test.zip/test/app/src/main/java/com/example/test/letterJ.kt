package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterJ : AppCompatActivity() {
    var NextJ: Button? = null
    var PrevJ: Button? = null
    var FirstJ: Button? = null
    var LastJ: Button? = null
    var OverviewJ: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_j)
        NextJ = findViewById(R.id.nextJ)
        PrevJ = findViewById(R.id.prevJ)
        FirstJ = findViewById(R.id.firstJ)
        LastJ = findViewById(R.id.lastJ)
        OverviewJ = findViewById(R.id.overviewJ)
        NextJ!!.setOnClickListener(View.OnClickListener {
            val intentJ = Intent(this@letterJ, letterK::class.java)
            startActivity(intentJ)
        })
        PrevJ!!.setOnClickListener(View.OnClickListener {
            val intentJ = Intent(this@letterJ, letterI::class.java)
            startActivity(intentJ)
        })
        FirstJ!!.setOnClickListener(View.OnClickListener {
            val intentJ = Intent(this@letterJ, letterA::class.java)
            startActivity(intentJ)
        })
        LastJ!!.setOnClickListener(View.OnClickListener {
            val intentJ = Intent(this@letterJ, letterZ::class.java)
            startActivity(intentJ)
        })
        OverviewJ!!.setOnClickListener(View.OnClickListener {
            val intentJ = Intent(this@letterJ, MainActivity::class.java)
            startActivity(intentJ)
        })
    }
}