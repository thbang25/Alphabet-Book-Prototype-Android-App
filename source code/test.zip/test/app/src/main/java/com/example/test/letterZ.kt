package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterZ : AppCompatActivity() {
    var PrevZ: Button? = null
    var FirstZ: Button? = null
    var OverviewZ: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_z)
        PrevZ = findViewById(R.id.prevZ)
        FirstZ = findViewById(R.id.firstZ)
        OverviewZ = findViewById(R.id.overviewZ)
        PrevZ!!.setOnClickListener(View.OnClickListener {
            val intentZ = Intent(this@letterZ, letterY::class.java)
            startActivity(intentZ)
        })
        FirstZ!!.setOnClickListener(View.OnClickListener {
            val intentZ = Intent(this@letterZ, letterA::class.java)
            startActivity(intentZ)
        })
        OverviewZ!!.setOnClickListener(View.OnClickListener {
            val intentZ = Intent(this@letterZ, MainActivity::class.java)
            startActivity(intentZ)
        })
    }
}