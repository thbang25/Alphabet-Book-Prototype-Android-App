package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterS : AppCompatActivity() {
    var NextS: Button? = null
    var PrevS: Button? = null
    var FirstS: Button? = null
    var LastS: Button? = null
    var OverviewS: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_s)
        NextS = findViewById(R.id.nextS)
        PrevS = findViewById(R.id.prevS)
        FirstS = findViewById(R.id.firstS)
        LastS = findViewById(R.id.lastS)
        OverviewS = findViewById(R.id.overviewS)
        NextS!!.setOnClickListener(View.OnClickListener {
            val intentS = Intent(this@letterS, letterT::class.java)
            startActivity(intentS)
        })
        PrevS!!.setOnClickListener(View.OnClickListener {
            val intentS = Intent(this@letterS, letterR::class.java)
            startActivity(intentS)
        })
        FirstS!!.setOnClickListener(View.OnClickListener {
            val intentS = Intent(this@letterS, letterA::class.java)
            startActivity(intentS)
        })
        LastS!!.setOnClickListener(View.OnClickListener {
            val intentS = Intent(this@letterS, letterZ::class.java)
            startActivity(intentS)
        })
        OverviewS!!.setOnClickListener(View.OnClickListener {
            val intentS = Intent(this@letterS, MainActivity::class.java)
            startActivity(intentS)
        })
    }
}