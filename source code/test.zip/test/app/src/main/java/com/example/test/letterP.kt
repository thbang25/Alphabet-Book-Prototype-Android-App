package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterP : AppCompatActivity() {
    var NextP: Button? = null
    var PrevP: Button? = null
    var FirstP: Button? = null
    var LastP: Button? = null
    var OverviewP: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_p)
        NextP = findViewById(R.id.nextP)
        PrevP = findViewById(R.id.prevP)
        FirstP = findViewById(R.id.firstP)
        LastP = findViewById(R.id.lastP)
        OverviewP = findViewById(R.id.overviewP)
        NextP!!.setOnClickListener(View.OnClickListener {
            val intentP = Intent(this@letterP, letterQ::class.java)
            startActivity(intentP)
        })
        PrevP!!.setOnClickListener(View.OnClickListener {
            val intentP = Intent(this@letterP, letterO::class.java)
            startActivity(intentP)
        })
        FirstP!!.setOnClickListener(View.OnClickListener {
            val intentP = Intent(this@letterP, letterA::class.java)
            startActivity(intentP)
        })
        LastP!!.setOnClickListener(View.OnClickListener {
            val intentP = Intent(this@letterP, letterZ::class.java)
            startActivity(intentP)
        })
        OverviewP!!.setOnClickListener(View.OnClickListener {
            val intentP = Intent(this@letterP, MainActivity::class.java)
            startActivity(intentP)
        })
    }
}