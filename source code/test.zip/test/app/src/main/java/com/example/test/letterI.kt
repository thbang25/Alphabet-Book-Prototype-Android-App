package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterI : AppCompatActivity() {
    var NextI: Button? = null
    var PrevI: Button? = null
    var FirstI: Button? = null
    var LastI: Button? = null
    var OverviewI: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_i)
        NextI = findViewById(R.id.nextI)
        PrevI = findViewById(R.id.prevI)
        FirstI = findViewById(R.id.firstI)
        LastI = findViewById(R.id.lastI)
        OverviewI = findViewById(R.id.overviewI)

        NextI!!.setOnClickListener(View.OnClickListener {
            val intentI = Intent(this@letterI, letterJ::class.java)
            startActivity(intentI)
        })
        PrevI!!.setOnClickListener(View.OnClickListener {
            val intentI = Intent(this@letterI, letterH::class.java)
            startActivity(intentI)
        })
        FirstI!!.setOnClickListener(View.OnClickListener {
            val intentI = Intent(this@letterI, letterA::class.java)
            startActivity(intentI)
        })
        LastI!!.setOnClickListener(View.OnClickListener {
            val intentI = Intent(this@letterI, letterZ::class.java)
            startActivity(intentI)
        })
        OverviewI!!.setOnClickListener(View.OnClickListener {
            val intentI = Intent(this@letterI, MainActivity::class.java)
            startActivity(intentI)
        })
    }
}