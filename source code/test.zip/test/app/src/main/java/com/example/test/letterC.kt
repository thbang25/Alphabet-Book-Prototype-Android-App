package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterC : AppCompatActivity() {
    var NextC: Button? = null
    var PrevC: Button? = null
    var FirstC: Button? = null
    var LastC: Button? = null
    var OverviewC: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_c)
        NextC = findViewById(R.id.nextC)
        PrevC = findViewById(R.id.prevC)
        FirstC = findViewById(R.id.firstC)
        LastC = findViewById(R.id.lastC)
        OverviewC = findViewById(R.id.overviewC)

        NextC!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterC, letterD::class.java)
            startActivity(intentFour)
        })
        PrevC!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterC, letterB::class.java)
            startActivity(intentFour)
        })
        FirstC!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterC, letterA::class.java)
            startActivity(intentFour)
        })
        LastC!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterC, letterZ::class.java)
            startActivity(intentFour)
        })
        OverviewC!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterC, MainActivity::class.java)
            startActivity(intentFour)
        })
    }
}