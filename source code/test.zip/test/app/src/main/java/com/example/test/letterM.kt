package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterM : AppCompatActivity() {
    var NextM: Button? = null
    var PrevM: Button? = null
    var FirstM: Button? = null
    var LastM: Button? = null
    var OverviewM: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_m)
        NextM = findViewById(R.id.nextM)
        PrevM = findViewById(R.id.prevM)
        FirstM = findViewById(R.id.firstM)
        LastM = findViewById(R.id.lastM)
        OverviewM = findViewById(R.id.overviewM)
        NextM!!.setOnClickListener(View.OnClickListener {
            val intentM = Intent(this@letterM, letterN::class.java)
            startActivity(intentM)
        })
        PrevM!!.setOnClickListener(View.OnClickListener {
            val intentM = Intent(this@letterM, letterL::class.java)
            startActivity(intentM)
        })
        FirstM!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterM, letterA::class.java)
            startActivity(intentFour)
        })
        LastM!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterM, letterZ::class.java)
            startActivity(intentFour)
        })
        OverviewM!!.setOnClickListener(View.OnClickListener {
            val intentFour = Intent(this@letterM, MainActivity::class.java)
            startActivity(intentFour)
        })
    }
}