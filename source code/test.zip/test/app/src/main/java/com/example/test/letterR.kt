package com.example.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class letterR : AppCompatActivity() {
    var NextR: Button? = null
    var PrevR: Button? = null
    var FirstR: Button? = null
    var LastR: Button? = null
    var OverviewR: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letter_r)
        NextR = findViewById(R.id.nextR)
        PrevR = findViewById(R.id.prevR)
        FirstR = findViewById(R.id.firstR)
        LastR = findViewById(R.id.lastR)
        OverviewR = findViewById(R.id.overviewR)

        NextR!!.setOnClickListener(View.OnClickListener {
            val intentR = Intent(this@letterR, letterS::class.java)
            startActivity(intentR)
        })
        PrevR!!.setOnClickListener(View.OnClickListener {
            val intentR = Intent(this@letterR, letterQ::class.java)
            startActivity(intentR)
        })
        FirstR!!.setOnClickListener(View.OnClickListener {
            val intentR = Intent(this@letterR, letterA::class.java)
            startActivity(intentR)
        })
        LastR!!.setOnClickListener(View.OnClickListener {
            val intentR = Intent(this@letterR, letterZ::class.java)
            startActivity(intentR)
        })
        OverviewR!!.setOnClickListener(View.OnClickListener {
            val intentR = Intent(this@letterR, MainActivity::class.java)
            startActivity(intentR)
        })
    }
}